#!/bin/bash

flip=$((RANDOM%2))

case $flip in
  0)
    echo 'Adventure 1!'
    echo 'You find yourself in a dark room with two doors. Do you take the door on the left or the right?'
    read choice
    ;;
  1)
    echo 'Adventure 2!'
    echo 'You are stranded on an island. Will you explore the forest or the beach?'
    read choice
    ;;
esac

# append choice to the game progress log
echo $choice >> SRC_A/game_progress.log