print('Welcome to the second adventure!')
print('You are stranded on an island. Will you explore the forest or the beach?')